// the link to your model provided by Teachable Machine export panel
const URL = "./my_model/";

let model, webcam, labelContainer, maxPredictions;

// Load the image model and setup the webcam
async function init() {
  const modelURL = URL + "model.json";
  const metadataURL = URL + "metadata.json";

  // load the model and metadata
  // Refer to tmImage.loadFromFiles() in the API to support files from a file picker
  // or files from your local hard drive
  // Note: the pose library adds "tmImage" object to your window (window.tmImage)
  model = await tmImage.load(modelURL, metadataURL);
  maxPredictions = model.getTotalClasses();

  // Convenience function to setup a webcam
  const flip = true; // whether to flip the webcam
  webcam = new tmImage.Webcam(
    window.innerHeight - 450,
    window.innerHeight - 450,
    flip
  ); // width, height, flip
  await webcam.setup(); // request access to the webcam
  await webcam.play();
  window.requestAnimationFrame(loop);

  // append elements to the DOM
  document.getElementById("webcam-container").appendChild(webcam.canvas);
  labelContainer = document.getElementById("label-container");
  for (let i = 0; i < maxPredictions; i++) {
    // and class labels
    var newDiv = document.createElement("div");
    // var newGraph = document.createElement("div");
    // newGraph.id = i + "graph";
    // newGraph.className = "graph";
    newDiv.id = i + "label";
    labelContainer.append(newDiv);
  }
  // tmpLabel = document.getElementById("0label");
  // tmpLabel.appendChild("span");
  // console.log(tmpLabel);

  for (let i = 0; i < maxPredictions; i++) {
    var nthLabel = document.getElementById(i + "label");
    var newDiv = document.createElement("div");
    nthLabel.append(newDiv);
  }
}

async function loop() {
  webcam.update(); // update the webcam frame
  await predict();
  window.requestAnimationFrame(loop);
}

// run the webcam image through the image model
async function predict() {
  // predict can take in an image, video or canvas html element
  const prediction = await model.predict(webcam.canvas);

  for (let i = 0; i < maxPredictions; i++) {
    var tmpArr = ["data" + (i + 1)];
    const classPrediction =
      prediction[i].className + ": " + prediction[i].probability.toFixed(2);

    tmpArr.push(prediction[i].probability);
    let nthLabel = document.getElementById(i + "label");
    nthLabel.innerHTML = classPrediction;

    // labelContainer.childNodes[i].innerText = classPrediction;
    //   labelContainer.childNodes[i].style.width =
    //     (prediction[i].probability * 500).toFixed(1) + "px";
    chart.load({
      columns: [tmpArr],
      append: false,
    });
  }
}

var chart = bb.generate({
  bindto: "#chart",
  data: {
    type: "bar",
    columns: [
      ["data1", 30],
      ["data2", 30],
      ["data3", 30],
      ["data4", 30],
    ],
  },
  size: {
    width: 300,
    heigh: 50,
  },
  bar: {
    radius: 2,
    width: 25,
  },

  axis: {
    x: {
      show: false,
    },
    y: {
      show: false,
    },
    rotated: true,
  },
});
